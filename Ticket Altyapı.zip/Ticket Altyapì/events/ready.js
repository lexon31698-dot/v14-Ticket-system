const { Events, ActivityType } = require("discord.js");

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ ${client.user.tag} başarıyla giriş yaptı!`);

    // Botun durumunu ayarla
    client.user.setPresence({
      activities: [
        {
          name: "NoxariaNW",
          type: ActivityType.Playing
        }
      ],
      status: "online" // "idle", "dnd", "invisible" da olabilir
    });
  }
};
