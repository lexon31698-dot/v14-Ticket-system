const { Events, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  name: Events.GuildMemberRemove,

  async execute(member) {
    const kanal = member.guild.channels.cache.get(config.hosgeldinKanalId);
    if (!kanal) return;

    const embed = new EmbedBuilder()
      .setAuthor({
        name: `${member.user.username} Sunucudan Ayrıldı`,
        iconURL: member.user.displayAvatarURL({ dynamic: true })
      })
      .setDescription(`
:admin blue: **Bir kullanıcı aramızdan ayrıldı**

📅 Hesap Oluşturma:
<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>

👥 Kalan Üye Sayısı:
**${member.guild.memberCount} kişi**
      `)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))

      // 🔽 2. koddaki arka plan görseli eklendi
      .setImage("https://i.imgur.com/yourBackgroundImage.png")

      .setColor("#e74c3c")
      .setFooter({ text: member.guild.name })
      .setTimestamp();

    kanal.send({ embeds: [embed] });
  }
};
