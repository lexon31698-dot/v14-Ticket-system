const { Events, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  name: Events.GuildMemberAdd,

  async execute(member) {
    const kanal = member.guild.channels.cache.get(config.hosgeldinKanalId);
    if (!kanal) return;

    const embed = new EmbedBuilder()
      .setAuthor({
        name: `${member.user.username} Sunucuya Katıldı`,
        iconURL: member.user.displayAvatarURL({ dynamic: true })
      })
      .setDescription(`
> 🎉 **Hoş Geldin <@${member.user.id}>**

> 📅 Hesap Oluşturma:
<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>

> 👥 Sunucu Üye Sayısı:
**${member.guild.memberCount} kişi**
      `)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))

      // 🔽 2. koddaki fotoğraf buraya eklendi
      .setImage("https://i.imgur.com/yourWelcomeImage.png")

      .setColor("#2ecc71")
      .setFooter({ text: member.guild.name })
      .setTimestamp();

    kanal.send({ embeds: [embed] });
  }
};
