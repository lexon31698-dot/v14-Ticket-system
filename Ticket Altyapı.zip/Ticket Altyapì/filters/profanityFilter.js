const { filterWords } = require('../../config.json');

module.exports = function(message) {
  const content = message.content.toLowerCase();
  return filterWords.some(word => content.includes(word));
};
