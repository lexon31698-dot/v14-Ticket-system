const { spamThreshold } = require('../../config.json');
const userMessageMap = new Map();

module.exports = function(message) {
  const now = Date.now();
  const userId = message.author.id;

  if (!userMessageMap.has(userId)) {
    userMessageMap.set(userId, []);
  }

  const timestamps = userMessageMap.get(userId).filter(ts => now - ts < 5000);
  timestamps.push(now);
  userMessageMap.set(userId, timestamps);

  return timestamps.length >= spamThreshold;
};
