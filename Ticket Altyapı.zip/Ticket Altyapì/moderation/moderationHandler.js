const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

const profanityWords = config.profanityWords.map(w => w.toLowerCase());
const adKeywords = config.adKeywords.map(k => k.toLowerCase());
const spamThreshold = config.spamThreshold || 5;

const userMessageMap = new Map();

module.exports = async function moderationHandler(message, client) {
  if (!message.guild || message.author.bot) return;

  const content = message.content.toLowerCase();
  const userId = message.author.id;
  const now = Date.now();

  const hasProfanity = profanityWords.some(word => content.includes(word));
  if (hasProfanity) return await handleViolation(message, client, 'Küfür içeriyor');

  const hasAd = adKeywords.some(keyword => content.includes(keyword));
  if (hasAd) return await handleViolation(message, client, 'Reklam içeriyor');

  if (!userMessageMap.has(userId)) userMessageMap.set(userId, []);
  const timestamps = userMessageMap.get(userId).filter(ts => now - ts < 5000);
  timestamps.push(now);
  userMessageMap.set(userId, timestamps);

  if (timestamps.length >= spamThreshold) {
    userMessageMap.set(userId, []);
    return await handleViolation(message, client, 'Spam tespit edildi');
  }
};

async function handleViolation(message, client, reason) {
  await message.delete().catch(() => {});

  const logChannel = message.guild.channels.cache.get(config.logChannelId);
  if (!logChannel) return;

  const embed = new EmbedBuilder()
    .setTitle('🚨 Mesaj Silindi')
    .setDescription(`**${message.author.tag}** adlı kullanıcıdan bir mesaj silindi.`)
    .addFields(
      { name: 'Sebep', value: reason, inline: true },
      { name: 'Kanal', value: `${message.channel}`, inline: true },
      { name: 'Kullanıcı ID', value: message.author.id, inline: true }
    )
    .setColor('#e74c3c')
    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
    .setTimestamp();

  logChannel.send({ embeds: [embed] });
}
